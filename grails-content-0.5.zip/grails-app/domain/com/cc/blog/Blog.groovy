package com.cc.blog

import com.cc.content.*
import org.grails.taggable.*

class Blog extends Content implements Taggable {

    static constraints = {
    }
}
