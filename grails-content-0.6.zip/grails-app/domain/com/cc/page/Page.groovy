package com.cc.page

import com.cc.content.*

class Page extends Content {

    static constraints = {
    }
}
